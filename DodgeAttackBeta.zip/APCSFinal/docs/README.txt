﻿Group Members: Eric Pedley, Osman Wong, Rishab Koka
Title: 
Dodge attack  [subject to change]
Intro:
Primarily, this program acts as a game, intended to provide quick, easy entertainment to bored individuals or possibly to act as inspiration for game design. Our program is a 2D top down game, in which you control a character with melee attacks and attempt to defeat ranged enemies, avoiding enemy attacks as much as possible. You have a few abilities that can be activated for certain amounts of time, as well as temporary power ups that can be attained by defeating enemies. The game is (intended to be) multi leveled, where you must defeat all enemies on the map without dying in order to win. Each level is a big square area with randomly placed obstacles all over it and enemies randomly placed. This game can be played by individuals of all ages.


Instructions:
WASD for movement
Right click to pick up/throw objects
Shift dash/sprint
Space to teleport(short range)
Deflected shots move to the mouse


Features
Must-Have:
2d top view map with obstacles that do not allow projectiles, the player, or enemies to move through
Player can move around on the map using WASD keys. 
Enemies exist in the game that moves around aimlessly and shoot at the player using hard coded AI.
Player can activate an ability which causes all projectiles to “bounce” off, reversing movement to the opposite direction and dealing no damage to the player
Player can use a melee attack that will damage enemies in a semicircle in front of themselves.


Want-to-Have:
Enemies will only shoot projectiles at player if they are in an area in the shape of a cone in front of the enemy.
Enemies can drop power-ups when they die that the player can pick up by walking over, giving the player increased speed or attack strength or invincibility.
Bullet-time ability that lets the player slow down time with the press of a button and can only be activated for a certain amount of time.
Player can temporarily activate certain abilities that enhance their movement abilities, such as teleportation
Creating Multi leveled game with levels increasing in difficulty as you go.


Stretch:
Add a feature where the player cannot see past obstacles 
multiplayer BR using networking
mini map which lets you see the enemies a small circle around you
Add animations to characters such as walking and melee
Items and/or terrain features that can be moved or thrown at an enemy


Class List:
Sprite, Player, Enemy, Projectile, Main, Window, Level, Menu, Vector, Character


Credits List:
Eric: Sprite, Player, Enemy, Projectile, Vector
Rishab: Level, Environment, Window, Main,Character
Osman: Menu


Sources:
Collision detection tutorial: https://www.metanetsoftware.com/technique/tutorialA.html




* Describe what each class does in class list
* Describe more what the level would look like
* What makes your game unique from other pre existing games (similar to Brawl Stars?)
* Sorry guys your program is too good