package game;
import java.util.ArrayList;

public class Environment {
	private Player players;
	private ArrayList<Enemy> enemies;
	
	public Environment() {
		
	}
	public Environment() {
		
	}
	
}
