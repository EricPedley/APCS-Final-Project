package game;

import processing.core.PImage;

public class Projectile extends Sprite {

	public float dx,dy;
	
	public Projectile(float x, float y, PImage img) {
		super(x, y, img);
	}
	
}
