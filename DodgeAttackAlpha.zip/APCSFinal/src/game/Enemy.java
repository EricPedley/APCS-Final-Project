package game;
import processing.core.PImage;

public class Enemy extends Sprite {

	public Enemy(float x, float y, PImage img) {
		super(x, y, img);
		// TODO Auto-generated constructor stub
	}

}
