package game;
public class Window {

}
